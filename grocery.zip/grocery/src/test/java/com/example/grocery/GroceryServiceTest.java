package com.example.grocery;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.grocery.model.GroceryProduct;
import com.example.grocery.repository.GroceryRepositoryImpl;
import com.example.grocery.service.GroceryServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class GroceryServiceTest {

	@InjectMocks
	GroceryServiceImpl groceryService;

	@Mock
	GroceryRepositoryImpl groceryRepository;

	@Test
	public void testGetAllProducts() {
		List<GroceryProduct> products = new ArrayList<>();
		products.add(new GroceryProduct(1, "milk"));
		products.add(new GroceryProduct(2, "bread"));
		Mockito.when(groceryRepository.getAllProducts()).thenReturn(products);
		List<GroceryProduct> groceryProducts = groceryService.getAllProducts();
		//System.out.println(groceryProducts.size());
		assertTrue(groceryProducts.size() == 2);
	}

}
