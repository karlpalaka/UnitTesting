package com.example.grocery.repository;

import java.util.List;

import com.example.grocery.model.GroceryProduct;

public interface GroceryRepository {
	
	public List<GroceryProduct> getAllProducts();

}
