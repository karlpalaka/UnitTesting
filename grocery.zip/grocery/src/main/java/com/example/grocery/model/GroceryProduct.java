package com.example.grocery.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class GroceryProduct {
	
	private int groceryProductId;
	private String groceryProductName;

}
