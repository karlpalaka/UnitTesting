package com.example.grocery.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.grocery.model.GroceryProduct;

@Repository
public class GroceryRepositoryImpl implements GroceryRepository {

	@Override
	public List<GroceryProduct> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
