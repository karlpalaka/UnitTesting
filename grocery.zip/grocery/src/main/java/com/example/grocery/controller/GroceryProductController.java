package com.example.grocery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.example.grocery.service.GroceryServiceImpl;

@RestController
public class GroceryProductController {
	
	@Autowired
	private GroceryServiceImpl groceryService;
	
	@RequestMapping(value="/groceryProductTest", method=RequestMethod.GET)
	public ResponseEntity<String> groceryProductTest()
	{
		groceryService.getAllProducts();
		return new ResponseEntity<String>("tested", HttpStatus.OK);
	}

}
